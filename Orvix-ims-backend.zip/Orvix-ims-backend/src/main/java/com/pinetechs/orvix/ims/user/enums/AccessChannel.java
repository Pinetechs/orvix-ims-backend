package com.pinetechs.orvix.ims.user.enums;

public enum AccessChannel {
    WEB,
    MOBILE,
    BOTH
}
