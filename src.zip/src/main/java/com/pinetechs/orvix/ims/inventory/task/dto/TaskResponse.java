package com.pinetechs.orvix.ims.inventory.task.dto;

import com.pinetechs.orvix.ims.inventory.common.enums.InventoryDomain;
import com.pinetechs.orvix.ims.inventory.common.enums.InventoryTaskStatus;

import java.time.LocalDateTime;

public class TaskResponse {
  private   String id ;
  private   String taskName;
  private   String taskNumber;
  private  String description;
  private InventoryTaskStatus status;
  private InventoryDomain inventoryDomain;
  private int progress;
  private String createBy ;
  private LocalDateTime closedAt ;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskNumber() {
        return taskNumber;
    }

    public void setTaskNumber(String taskNumber) {
        this.taskNumber = taskNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public InventoryTaskStatus getStatus() {
        return status;
    }

    public void setStatus(InventoryTaskStatus status) {
        this.status = status;
    }

    public InventoryDomain getInventoryDomain() {
        return inventoryDomain;
    }

    public void setInventoryDomain(InventoryDomain inventoryDomain) {
        this.inventoryDomain = inventoryDomain;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public LocalDateTime getClosedAt() {
        return closedAt;
    }

    public void setClosedAt(LocalDateTime closedAt) {
        this.closedAt = closedAt;
    }
}
