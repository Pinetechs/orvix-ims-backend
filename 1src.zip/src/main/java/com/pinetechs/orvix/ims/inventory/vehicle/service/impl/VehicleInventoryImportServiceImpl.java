package com.pinetechs.orvix.ims.inventory.vehicle.service.impl;

import com.pinetechs.orvix.ims.common.exception.BusinessException;
import com.pinetechs.orvix.ims.company.entity.Company;
import com.pinetechs.orvix.ims.file.entity.UploadedFile;
import com.pinetechs.orvix.ims.file.service.UploadedFileService;
import com.pinetechs.orvix.ims.inventory.common.dto.UploadExcelResponse;
import com.pinetechs.orvix.ims.inventory.common.enums.InventoryDomain;
import com.pinetechs.orvix.ims.inventory.common.enums.InventoryTaskStatus;
import com.pinetechs.orvix.ims.inventory.task.entity.InventoryTask;
import com.pinetechs.orvix.ims.inventory.task.repository.InventoryTaskRepository;
import com.pinetechs.orvix.ims.inventory.vehicle.controller.VehicleInventoryItemResponse;
import com.pinetechs.orvix.ims.inventory.vehicle.entity.VehicleInventoryItem;
import com.pinetechs.orvix.ims.inventory.vehicle.repository.VehicleInventoryItemRepository;
import com.pinetechs.orvix.ims.inventory.vehicle.repository.VehicleInventoryLocationRepository;
import com.pinetechs.orvix.ims.inventory.vehicle.service.VehicleInventoryImportService;
import com.pinetechs.orvix.ims.jobs.entity.BackgroundJob;
import com.pinetechs.orvix.ims.jobs.enums.JobStatus;
import com.pinetechs.orvix.ims.jobs.enums.JobType;
import com.pinetechs.orvix.ims.jobs.repository.BackgroundJobRepository;
import com.pinetechs.orvix.ims.security.AccessPolicyService;
import com.pinetechs.orvix.ims.user.entity.User;
import jakarta.transaction.Transactional;
import org.apache.poi.ss.usermodel.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

@Service
@Transactional
public class VehicleInventoryImportServiceImpl implements VehicleInventoryImportService {

    private final InventoryTaskRepository inventoryTaskRepository;
    private final VehicleInventoryItemRepository itemRepository;
    private final VehicleInventoryLocationRepository locationRepository;
    private final AccessPolicyService accessPolicyService;
    private final UploadedFileService uploadedFileService ;
    private final BackgroundJobRepository backgroundJobRepository ;

    public VehicleInventoryImportServiceImpl(InventoryTaskRepository inventoryTaskRepository, VehicleInventoryItemRepository itemRepository, VehicleInventoryLocationRepository locationRepository, AccessPolicyService accessPolicyService, UploadedFileService uploadedFileService, BackgroundJobRepository backgroundJobRepository) {
        this.inventoryTaskRepository = inventoryTaskRepository;
        this.itemRepository = itemRepository;
        this.locationRepository = locationRepository;
        this.accessPolicyService = accessPolicyService;
        this.uploadedFileService = uploadedFileService;
        this.backgroundJobRepository = backgroundJobRepository;
    }

    @Override
    @Transactional
    public UploadExcelResponse uploadExcel(Long taskId, MultipartFile file, User currentUser) {
        InventoryTask task = inventoryTaskRepository.findById(taskId).orElseThrow(() -> new BusinessException(HttpStatus.BAD_REQUEST, "Inventory task not found"));

        Company company = task.getCompany();

        if (task.getInventoryDomain() != InventoryDomain.VEHICLE) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "Task is not a vehicle inventory task");
        }

        if (task.getStatus() != InventoryTaskStatus.DRAFT) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "Excel can be imported only when task is DRAFT");
        }

        accessPolicyService.assertCanImportExcel(currentUser, company.getId(), InventoryDomain.VEHICLE);

        try {
          UploadedFile uploadedFile = uploadedFileService.upload(file, "vehicle-inventory", true, false);

            BackgroundJob job = new BackgroundJob();
            job.setJobType(JobType.VEHICLE_IMPORT);
            job.setStatus(JobStatus.PENDING);
            job.setJobName("Vehicle Inventory Import for Task ID: " + taskId);
            job.setRelatedId(taskId);
            job.setMaxRetry(3);
            job.setRelatedFile(uploadedFile.getFilePath());
            job.setScheduledTime(LocalDateTime.now());
            job=  backgroundJobRepository.save(job);


          UploadExcelResponse response = new UploadExcelResponse();

           response.setJobId(job.getId());
           response.setTaskId(taskId);
           response.setFilePath(uploadedFile.getPublicUrl());
           response.setFileName(uploadedFile.getFileName());
            return response;


        } catch (IOException e) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upload file");
        }


    }


    @Transactional()
    public Page<VehicleInventoryItemResponse> getImportedVehicleItems(Long taskId, Pageable pageable, User currentUser) {
        InventoryTask task = inventoryTaskRepository.findById(taskId).orElseThrow(() -> new BusinessException(HttpStatus.BAD_REQUEST,"Inventory task not found"));


        if (task.getInventoryDomain() != InventoryDomain.VEHICLE) {
            throw new BusinessException(HttpStatus.BAD_REQUEST,"Task is not a vehicle inventory task");
        }

        Company company = task.getCompany();

        accessPolicyService.assertCanViewInventoryTask(currentUser, company.getId(),InventoryDomain.VEHICLE);

        return itemRepository.findByInventoryTaskIdOrderByIdAsc(taskId, pageable).map(this::toResponse);
    }


    private VehicleInventoryItemResponse toResponse(VehicleInventoryItem item) {
         VehicleInventoryItemResponse vehicleInventoryItemResponse = new VehicleInventoryItemResponse();



        vehicleInventoryItemResponse.setId(item.getId());
        vehicleInventoryItemResponse   .setPartNo(item.getPartNo());
        vehicleInventoryItemResponse   .setMake(item.getMake());
        vehicleInventoryItemResponse   .setModelName(item.getModelName());
        vehicleInventoryItemResponse.setModelYear(item.getModelYear());
        vehicleInventoryItemResponse    .setVinNo(item.getVinNo());
        vehicleInventoryItemResponse   .setSpecification(item.getSpecification());
        vehicleInventoryItemResponse     .setQuantity(item.getQuantity());
        vehicleInventoryItemResponse  .setReceiptDate(item.getReceiptDate());
        vehicleInventoryItemResponse  .setColorNo(item.getColorNo());
        vehicleInventoryItemResponse   .setInteriorColor(item.getInteriorColor());
        vehicleInventoryItemResponse   .setMchStatus(item.getMchStatus());
        vehicleInventoryItemResponse   .setStockStatus(item.getStockStatus());
        vehicleInventoryItemResponse   .setLocation(item.getLocation());
        vehicleInventoryItemResponse  .setStoreNo(item.getStoreNo());
        vehicleInventoryItemResponse  .setDarArtId(item.getDarArtId());

        return vehicleInventoryItemResponse;
    }




    private Map<String, Integer> readColumns(Row headerRow) {
        Map<String, Integer> columns = new HashMap<>();

        for (Cell cell : headerRow) {
            String columnName = getCellString(cell);
            if (columnName != null && !columnName.isBlank()) {
                columns.put(columnName.trim(), cell.getColumnIndex());
            }
        }

        return columns;
    }

    private List<String> getMissingRequiredColumns(Map<String, Integer> columns) {
        List<String> requiredColumns = List.of(
                "VIN_NO",
                "ST_STORE_NO",
                "LOCATION"
        );

        List<String> missing = new ArrayList<>();

        for (String requiredColumn : requiredColumns) {
            if (!columns.containsKey(requiredColumn)) {
                missing.add(requiredColumn);
            }
        }

        return missing;
    }



    private boolean isEmptyRow(Row row) {
        for (Cell cell : row) {
            if (getCellString(cell) != null && !getCellString(cell).isBlank()) {
                return false;
            }
        }
        return true;
    }

    private String getString(Row row, Integer index) {
        if (index == null) {
            return null;
        }

        Cell cell = row.getCell(index);
        return getCellString(cell);
    }

    private String getCellString(Cell cell) {
        if (cell == null) {
            return null;
        }

        DataFormatter formatter = new DataFormatter();
        String value = formatter.formatCellValue(cell);

        if (value == null) {
            return null;
        }

        return value.trim();
    }

    private Integer getInteger(Row row, Integer index) {
        String value = getString(row, index);

        if (value == null || value.isBlank()) {
            return null;
        }

        try {
            return Double.valueOf(value).intValue();
        } catch (Exception e) {
            return null;
        }
    }

    private LocalDate getDate(Row row, Integer index) {
        if (index == null) {
            return null;
        }

        Cell cell = row.getCell(index);

        if (cell == null) {
            return null;
        }

        try {
            if (DateUtil.isCellDateFormatted(cell)) {
                return cell.getDateCellValue()
                        .toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();
            }

            String value = getCellString(cell);
            if (value == null || value.isBlank()) {
                return null;
            }

            double serial = Double.parseDouble(value);
            return DateUtil.getJavaDate(serial)
                    .toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();

        } catch (Exception e) {
            return null;
        }
    }

    private String normalize(String value) {
        if (value == null) {
            return null;
        }

        return value.trim();
    }
}